import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/header";
import HeadlineCarousel from "@/components/headline-carousel";
import NewsGrid from "@/components/news-grid";
import { type Article } from "@shared/schema";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLanguage, setSelectedLanguage] = useState("all");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [isSearchVisible, setIsSearchVisible] = useState(false);
  const [isAdminVisible, setIsAdminVisible] = useState(false);

  // Fetch all articles
  const { data: articles = [], isLoading, refetch } = useQuery<Article[]>({
    queryKey: ['/api/articles'],
    refetchInterval: 5 * 60 * 1000, // Auto-refresh every 5 minutes
  });

  // Fetch breaking news for carousel
  const { data: breakingNews = [] } = useQuery<Article[]>({
    queryKey: ['/api/articles/breaking'],
    refetchInterval: 5 * 60 * 1000,
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        isSearchVisible={isSearchVisible}
        onToggleSearch={() => setIsSearchVisible(!isSearchVisible)}
        isAdminVisible={isAdminVisible}
        onToggleAdmin={() => setIsAdminVisible(!isAdminVisible)}
      />

      <HeadlineCarousel articles={breakingNews} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Latest News</h2>
            <p className="text-gray-600 text-lg">Stay updated with the latest developments from Burundi</p>
          </div>
          <div className="flex items-center space-x-4 mt-4 md:mt-0">
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <div className="w-2 h-2 bg-burundi-green rounded-full animate-pulse"></div>
              <span className="font-medium">Auto-refresh: 5 min</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-700 font-medium">Language:</span>
              <select 
                value={selectedLanguage}
                onChange={(e) => setSelectedLanguage(e.target.value)}
                className="text-sm border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-burundi-blue focus:outline-none bg-white shadow-sm"
              >
                <option value="all">All</option>
                <option value="English">English</option>
                <option value="French">French</option>
                <option value="Kirundi">Kirundi</option>
              </select>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-700 font-medium">Category:</span>
              <select 
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="text-sm border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-burundi-blue focus:outline-none bg-white shadow-sm"
              >
                <option value="all">All</option>
                <option value="Politics">Politics</option>
                <option value="Economy">Economy</option>
                <option value="Sports">Sports</option>
                <option value="Health">Health</option>
                <option value="Education">Education</option>
                <option value="Culture">Culture</option>
                <option value="Agriculture">Agriculture</option>
              </select>
            </div>
          </div>
        </div>

        <NewsGrid 
          articles={articles.filter(article => {
            const matchesSearch = !searchQuery || 
              article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
              article.description?.toLowerCase().includes(searchQuery.toLowerCase());
            const matchesLanguage = selectedLanguage === "all" || article.language === selectedLanguage;
            const matchesCategory = selectedCategory === "all" || article.category === selectedCategory;
            return matchesSearch && matchesLanguage && matchesCategory;
          })} 
          isLoading={isLoading} 
        />
      </main>

      {/* Footer */}
      <footer className="bg-burundi-black text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Logo and Description */}
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-burundi-blue rounded-lg flex items-center justify-center">
                  <i className="fas fa-newspaper text-white text-lg"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold">All Burundi News</h3>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-burundi-red rounded-full animate-pulse"></div>
                    <span className="text-gray-300 text-xs">LIVE</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-300 mb-4">
                Your comprehensive source for the latest news and developments from Burundi, 
                featuring multi-language coverage and real-time updates.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Breaking News</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Politics</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Economy</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Sports</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Culture</a></li>
              </ul>
            </div>

            {/* Languages */}
            <div>
              <h4 className="text-lg font-semibold mb-4">Languages</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-gray-300 hover:text-white transition-colors">English</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Français</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Kirundi</a></li>
              </ul>
            </div>
          </div>

          {/* Developer Attribution */}
          <div className="border-t border-gray-700 mt-8 pt-6">
            <div className="bg-burundi-blue px-6 py-4 rounded-lg">
              <p className="text-white text-sm text-center">
                Developed by <strong>Ndayikeze Apollinaire</strong> Founder & CEO, Smart Design Experts | 
                Senior Communication Advisor, National Assembly of Burundi | IT Specialist
              </p>
            </div>
          </div>

          {/* Copyright */}
          <div className="text-center mt-6 text-sm text-gray-400">
            <p>&copy; 2024 All Burundi News. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
