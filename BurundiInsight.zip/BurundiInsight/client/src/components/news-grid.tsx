import { ExternalLink, Clock, Globe } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { type Article } from "@shared/schema";

interface NewsGridProps {
  articles: Article[];
  isLoading: boolean;
}

export default function NewsGrid({ articles, isLoading }: NewsGridProps) {
  const getCategoryColor = (category: string) => {
    switch (category?.toLowerCase()) {
      case 'politics': return 'bg-burundi-blue text-white';
      case 'economy': return 'bg-burundi-green text-white';
      case 'sports': return 'bg-orange-600 text-white';
      case 'health': return 'bg-burundi-red text-white';
      case 'education': return 'bg-purple-600 text-white';
      case 'culture': return 'bg-yellow-600 text-white';
      case 'agriculture': return 'bg-green-700 text-white';
      default: return 'bg-gray-600 text-white';
    }
  };

  const getLanguageFlag = (language: string) => {
    switch (language?.toLowerCase()) {
      case 'french': return '🇫🇷';
      case 'kirundi': return '🇧🇮';
      default: return '🇺🇸';
    }
  };

  if (isLoading) {
    return (
      <div className="text-center py-12">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-burundi-blue rounded-full mb-4 shadow-lg">
          <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
        </div>
        <p className="text-gray-700 text-lg font-medium">Fetching latest news articles...</p>
      </div>
    );
  }

  if (articles.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-burundi-blue bg-opacity-10 rounded-full mb-4">
          <Globe className="w-8 h-8 text-burundi-blue" />
        </div>
        <h3 className="text-xl font-bold text-gray-900 mb-2">No Articles Found</h3>
        <p className="text-gray-600 max-w-md mx-auto">No news articles match your current filters. Try adjusting your search or language settings to see more content.</p>
      </div>
    );
  }

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {articles.map((article) => (
          <Card key={article.id} className="group hover:shadow-xl transition-all duration-300 overflow-hidden">
            <div className="relative">
              {article.imageUrl ? (
                <img 
                  src={article.imageUrl} 
                  alt={article.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
              ) : (
                <div className="w-full h-48 bg-gradient-to-br from-burundi-blue to-blue-600 flex items-center justify-center">
                  <Globe className="w-12 h-12 text-white opacity-50" />
                </div>
              )}
              <div className="absolute top-4 left-4 flex items-center space-x-2">
                <span className={`text-xs px-2 py-1 rounded-full font-medium ${getCategoryColor(article.category || 'General')}`}>
                  {article.category || 'General'}
                </span>
                <span className="text-lg">
                  {getLanguageFlag(article.language)}
                </span>
              </div>
            </div>
            
            <CardContent className="p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2 group-hover:text-burundi-blue transition-colors">
                {article.title}
              </h3>
              
              <p className="text-gray-700 text-sm mb-4 line-clamp-3 leading-relaxed">
                {article.description || "Read the full article for more details..."}
              </p>
              
              <div className="flex items-center justify-between text-xs text-gray-600 mb-4">
                <div className="flex items-center space-x-2">
                  <Globe className="w-3 h-3 text-burundi-blue" />
                  <span className="truncate max-w-24 font-medium">{article.source}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="w-3 h-3 text-burundi-blue" />
                  <span className="font-medium">
                    {new Date(article.publishedAt).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      hour: 'numeric',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
              </div>

              <Button
                variant="outline"
                size="sm"
                className="w-full group-hover:bg-burundi-blue group-hover:text-white transition-colors"
                onClick={() => window.open(article.url, '_blank')}
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Read Full Article
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Load More Button */}
      {articles.length >= 6 && (
        <div className="text-center mt-12">
          <Button 
            className="bg-burundi-blue hover:bg-blue-700 text-white px-8 py-3 font-medium"
            size="lg"
          >
            Load More Articles
          </Button>
        </div>
      )}
    </>
  );
}
