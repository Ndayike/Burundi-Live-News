import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Flame } from "lucide-react";
import { Button } from "@/components/ui/button";
import { type Article } from "@shared/schema";

interface HeadlineCarouselProps {
  articles: Article[];
}

export default function HeadlineCarousel({ articles }: HeadlineCarouselProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  // Auto-rotate carousel every 10 seconds for 90 days display
  useEffect(() => {
    if (articles.length === 0) return;
    
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % articles.length);
    }, 10000); // 10 seconds rotation

    return () => clearInterval(interval);
  }, [articles.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % articles.length);
  };

  const previousSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + articles.length) % articles.length);
  };

  if (articles.length === 0) {
    return (
      <section className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-burundi-black flex items-center">
              <Flame className="w-6 h-6 text-burundi-red mr-3" />
              Breaking News
            </h2>
          </div>
          <div className="h-80 bg-gradient-to-r from-slate-800 to-slate-900 rounded-xl flex items-center justify-center shadow-2xl">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-white bg-opacity-20 rounded-full mb-4">
                <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              </div>
              <p className="text-white text-xl font-medium">Loading breaking news...</p>
            </div>
          </div>
        </div>
      </section>
    );
  }

  const currentArticle = articles[currentSlide];

  const getCategoryColor = (category: string) => {
    switch (category?.toLowerCase()) {
      case 'politics': return 'bg-burundi-blue';
      case 'economy': return 'bg-burundi-green';
      case 'sports': return 'bg-orange-600';
      case 'health': return 'bg-burundi-red';
      case 'education': return 'bg-purple-600';
      case 'culture': return 'bg-yellow-600';
      default: return 'bg-burundi-red';
    }
  };

  return (
    <section className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="relative">
          {/* Carousel Header */}
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-burundi-black flex items-center">
              <Flame className="w-6 h-6 text-burundi-red mr-3" />
              Breaking News
            </h2>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={previousSlide}
                className="p-2 hover:bg-burundi-blue hover:text-white border-burundi-blue text-burundi-blue transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={nextSlide}
                className="p-2 hover:bg-burundi-blue hover:text-white border-burundi-blue text-burundi-blue transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Carousel Content */}
          <div className="relative h-80 bg-gradient-to-r from-slate-800 to-slate-900 rounded-xl overflow-hidden shadow-2xl">
            {/* Dark overlay for better text readability */}
            <div className="absolute inset-0 bg-black bg-opacity-50 z-5"></div>
            
            <div className="absolute inset-0 flex items-center">
              {currentArticle.imageUrl && (
                <img 
                  src={currentArticle.imageUrl} 
                  alt={currentArticle.title}
                  className="absolute inset-0 w-full h-full object-cover opacity-20"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
              )}
              <div className="relative z-10 px-8 text-white max-w-4xl">
                <h3 className="text-3xl md:text-4xl font-bold mb-4 leading-tight line-clamp-2 text-white drop-shadow-lg">
                  {currentArticle.title}
                </h3>
                <p className="text-xl mb-4 line-clamp-3 text-gray-100 drop-shadow-md">
                  {currentArticle.description || "Stay informed with the latest developments..."}
                </p>
                <div className="flex items-center space-x-4 text-sm">
                  <span className={`${getCategoryColor(currentArticle.category || 'Breaking')} text-white px-3 py-1 rounded-full font-semibold shadow-lg`}>
                    {currentArticle.category || 'Breaking'}
                  </span>
                  <span className="text-gray-200 font-medium">
                    {currentArticle.source} • {new Date(currentArticle.publishedAt).toLocaleString('en-US', {
                      hour: 'numeric',
                      minute: '2-digit',
                      hour12: true
                    })}
                  </span>
                </div>
              </div>
            </div>

            {/* Progress Indicator */}
            <div className="absolute bottom-4 left-8 flex space-x-2">
              {articles.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentSlide ? 'bg-white scale-110' : 'bg-white bg-opacity-60 hover:bg-opacity-80'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
