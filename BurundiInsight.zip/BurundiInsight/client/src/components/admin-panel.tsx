import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { X, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { type NewsSource } from "@shared/schema";

interface AdminPanelProps {
  onClose: () => void;
}

export default function AdminPanel({ onClose }: AdminPanelProps) {
  const [newSourceName, setNewSourceName] = useState("");
  const [newSourceUrl, setNewSourceUrl] = useState("");
  const [newSourceApiType, setNewSourceApiType] = useState("rss");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch news sources
  const { data: sources = [] } = useQuery<NewsSource[]>({
    queryKey: ['/api/sources'],
  });

  // Add news source mutation
  const addSourceMutation = useMutation({
    mutationFn: async (sourceData: { name: string; url: string; apiType: string; isActive: boolean }) => {
      const response = await apiRequest("POST", "/api/sources", sourceData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sources'] });
      setNewSourceName("");
      setNewSourceUrl("");
      setNewSourceApiType("rss");
      toast({
        title: "Source Added",
        description: "News source has been added successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add news source.",
        variant: "destructive",
      });
    },
  });

  // Delete news source mutation
  const deleteSourceMutation = useMutation({
    mutationFn: async (sourceId: number) => {
      const response = await apiRequest("DELETE", `/api/sources/${sourceId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sources'] });
      toast({
        title: "Source Removed",
        description: "News source has been removed successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to remove news source.",
        variant: "destructive",
      });
    },
  });

  // Refresh news mutation
  const refreshNewsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/articles/refresh");
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/articles'] });
      queryClient.invalidateQueries({ queryKey: ['/api/articles/breaking'] });
      toast({
        title: "News Refreshed",
        description: data.message || "News articles have been refreshed.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to refresh news.",
        variant: "destructive",
      });
    },
  });

  const handleAddSource = () => {
    if (!newSourceName.trim() || !newSourceUrl.trim()) {
      toast({
        title: "Validation Error",
        description: "Please provide both name and URL for the news source.",
        variant: "destructive",
      });
      return;
    }

    addSourceMutation.mutate({
      name: newSourceName,
      url: newSourceUrl,
      apiType: newSourceApiType,
      isActive: true,
    });
  };

  const handleDeleteSource = (sourceId: number) => {
    deleteSourceMutation.mutate(sourceId);
  };

  return (
    <div className="bg-yellow-50 border-b border-yellow-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-burundi-black">Admin Panel - Source Management</h3>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Add News Source */}
          <div className="space-y-4">
            <h4 className="font-medium text-burundi-black">Add News Source</h4>
            <div className="space-y-3">
              <Input
                placeholder="Source name (e.g., Burundi24)"
                value={newSourceName}
                onChange={(e) => setNewSourceName(e.target.value)}
              />
              <Input
                placeholder="Source URL"
                value={newSourceUrl}
                onChange={(e) => setNewSourceUrl(e.target.value)}
              />
              <Select value={newSourceApiType} onValueChange={setNewSourceApiType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select API type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rss">RSS Feed</SelectItem>
                  <SelectItem value="newsapi">NewsAPI</SelectItem>
                  <SelectItem value="gnews">GNews</SelectItem>
                  <SelectItem value="bing">Bing News</SelectItem>
                </SelectContent>
              </Select>
              <Button 
                onClick={handleAddSource}
                disabled={addSourceMutation.isPending}
                className="w-full bg-burundi-green hover:bg-green-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                {addSourceMutation.isPending ? "Adding..." : "Add Source"}
              </Button>
            </div>
          </div>

          {/* Manage Existing Sources */}
          <div className="space-y-4">
            <h4 className="font-medium text-burundi-black">Manage Sources</h4>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {sources.map((source) => (
                <div key={source.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{source.name}</p>
                    <p className="text-xs text-gray-500 truncate">{source.url}</p>
                    <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                      source.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {source.apiType}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteSource(source.id)}
                    disabled={deleteSourceMutation.isPending}
                    className="text-red-600 hover:text-red-800"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
              {sources.length === 0 && (
                <p className="text-sm text-gray-500 text-center py-4">No sources configured</p>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-4">
            <h4 className="font-medium text-burundi-black">Actions</h4>
            <div className="space-y-3">
              <Button 
                onClick={() => refreshNewsMutation.mutate()}
                disabled={refreshNewsMutation.isPending}
                className="w-full bg-burundi-blue hover:bg-blue-700"
              >
                {refreshNewsMutation.isPending ? "Refreshing..." : "Refresh News Now"}
              </Button>
              <div className="text-xs text-gray-600">
                <p>• Auto-refresh: Every 5 minutes</p>
                <p>• Sources: {sources.filter(s => s.isActive).length} active</p>
                <p>• Last update: {new Date().toLocaleTimeString()}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
