import { apiRequest } from "./queryClient";
import { type Article } from "@shared/schema";

export const newsApi = {
  // Get all articles with optional filters
  getArticles: async (params?: {
    category?: string;
    language?: string;
    search?: string;
  }): Promise<Article[]> => {
    const searchParams = new URLSearchParams();
    if (params?.category && params.category !== "all") {
      searchParams.set("category", params.category);
    }
    if (params?.language && params.language !== "all") {
      searchParams.set("language", params.language);
    }
    if (params?.search) {
      searchParams.set("search", params.search);
    }

    const url = `/api/articles${searchParams.toString() ? `?${searchParams.toString()}` : ""}`;
    const response = await apiRequest("GET", url);
    return response.json();
  },

  // Get breaking news
  getBreakingNews: async (): Promise<Article[]> => {
    const response = await apiRequest("GET", "/api/articles/breaking");
    return response.json();
  },

  // Manually refresh news
  refreshNews: async (): Promise<{ message: string; articles?: Article[] }> => {
    const response = await apiRequest("POST", "/api/articles/refresh");
    return response.json();
  },
};
