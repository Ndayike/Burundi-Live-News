# Burundi News Aggregator

## Overview

This is a React-based news aggregation application that collects and displays news articles related to Burundi from multiple sources. The application features a modern, responsive design with real-time news fetching, categorization, and search functionality. Built with a full-stack TypeScript architecture using Express.js backend and React frontend.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a monorepo structure with clear separation between client and server code:

```
├── client/           # React frontend application
├── server/           # Express.js backend API
├── shared/           # Shared TypeScript schemas and types
└── migrations/       # Database migration files
```

### Technology Stack

- **Frontend**: React 18 with TypeScript, Vite for bundling
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query (React Query)
- **Routing**: Wouter (lightweight React router)
- **News APIs**: Multiple sources (NewsAPI, GNews, Bing News)

## Key Components

### Frontend Architecture

The client application is built with modern React patterns:

- **Component Structure**: Uses shadcn/ui component library for consistent UI elements
- **State Management**: TanStack Query for server state management and caching
- **Styling**: Tailwind CSS with custom Burundi-themed color palette
- **Responsive Design**: Mobile-first approach with adaptive layouts

Key frontend components:
- `HeadlineCarousel`: Rotating display of breaking news
- `NewsGrid`: Grid layout for article display with filtering
- `SearchBar`: Real-time search functionality
- `AdminPanel`: Management interface for news sources

### Backend Architecture

Express.js REST API with the following structure:

- **Route Handlers**: Centralized in `server/routes.ts`
- **Data Layer**: Storage abstraction with in-memory implementation
- **News Fetching**: Service layer for external API integration
- **Middleware**: Request logging and error handling

### Database Design

PostgreSQL schema managed with Drizzle ORM:

```sql
- users: User authentication (username, password)
- articles: News articles with metadata (title, content, source, category, language, timestamps)
- news_sources: Configurable news sources (name, url, api_type, is_active)
```

## Data Flow

1. **News Ingestion**: Scheduled tasks fetch news from external APIs every 5 minutes
2. **Data Processing**: Articles are processed, deduplicated, and stored in PostgreSQL
3. **Client Requests**: Frontend queries backend API endpoints for articles
4. **Real-time Updates**: Auto-refresh functionality keeps content current
5. **Search & Filtering**: Server-side filtering by category, language, and search terms

### News Sources Integration

The application integrates with multiple news sources:
- **Veridade Blog**: Primary integrated blog source (https://veridade.blogspot.com) with RSS feed parsing
- **Priority Veridade Articles**: 10 specific articles displayed on 10-second rotation for 90 days (July 2025 - October 2025)
- **NewsAPI**: International news service with API integration
- **GNews**: Alternative news aggregation service  
- **Bing News**: Microsoft's news search API

The system prioritizes specific Veridade blog articles including political analysis, regional cooperation, and social commentary. Articles are automatically categorized and support multiple languages (English, French, Kirundi). The carousel rotates through priority articles every 10 seconds as requested.

## External Dependencies

### Production Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitives
- **express**: Node.js web framework
- **wouter**: Lightweight React routing

### Development Dependencies
- **vite**: Build tool and dev server
- **typescript**: Type checking
- **tailwindcss**: CSS framework
- **drizzle-kit**: Database migration tool

## Deployment Strategy

The application is configured for Replit deployment with:

- **Build Process**: Vite builds the frontend, esbuild bundles the backend
- **Environment**: NODE_ENV-based configuration
- **Database**: PostgreSQL via DATABASE_URL environment variable
- **Static Assets**: Frontend served from Express in production
- **Development**: Vite dev server with HMR for frontend development

### Database Management

- **Migrations**: Managed through Drizzle Kit with `db:push` command
- **Schema Evolution**: Version-controlled schema changes in `shared/schema.ts`
- **Data Cleanup**: Automated removal of articles older than 24 hours

### Error Handling

- **Client**: Toast notifications for user feedback
- **Server**: Centralized error middleware with status code handling
- **Database**: Connection error recovery and transaction management

The application prioritizes reliability with automatic news fetching, graceful error handling, and responsive design for optimal user experience across devices.