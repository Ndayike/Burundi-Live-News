import { users, articles, newsSources, type User, type InsertUser, type Article, type InsertArticle, type NewsSource, type InsertNewsSource } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllArticles(): Promise<Article[]>;
  getArticlesByCategory(category: string): Promise<Article[]>;
  getArticlesByLanguage(language: string): Promise<Article[]>;
  searchArticles(query: string): Promise<Article[]>;
  createArticle(article: InsertArticle): Promise<Article>;
  createMultipleArticles(articles: InsertArticle[]): Promise<Article[]>;
  deleteOldArticles(hoursOld: number): Promise<void>;
  
  getAllNewsSources(): Promise<NewsSource[]>;
  getActiveNewsSources(): Promise<NewsSource[]>;
  createNewsSource(source: InsertNewsSource): Promise<NewsSource>;
  deleteNewsSource(id: number): Promise<boolean>;
  toggleNewsSource(id: number, isActive: boolean): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private articles: Map<number, Article>;
  private newsSources: Map<number, NewsSource>;
  private currentUserId: number;
  private currentArticleId: number;
  private currentSourceId: number;

  constructor() {
    this.users = new Map();
    this.articles = new Map();
    this.newsSources = new Map();
    this.currentUserId = 1;
    this.currentArticleId = 1;
    this.currentSourceId = 1;
    
    // Initialize with default news sources
    this.initializeDefaultSources();
  }

  private initializeDefaultSources() {
    const defaultSources = [
      { name: "Veridade Blog", url: "https://veridade.blogspot.com", apiType: "rss", isActive: true },
      { name: "NewsAPI", url: "https://newsapi.org", apiType: "newsapi", isActive: true },
      { name: "GNews", url: "https://gnews.io", apiType: "gnews", isActive: true },
      { name: "Bing News", url: "https://api.bing.microsoft.com", apiType: "bing", isActive: true },
    ];
    
    defaultSources.forEach(source => {
      const newsSource: NewsSource = {
        ...source,
        id: this.currentSourceId++,
        addedAt: new Date(),
      };
      this.newsSources.set(newsSource.id, newsSource);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllArticles(): Promise<Article[]> {
    return Array.from(this.articles.values()).sort(
      (a, b) => b.publishedAt.getTime() - a.publishedAt.getTime()
    );
  }

  async getArticlesByCategory(category: string): Promise<Article[]> {
    return Array.from(this.articles.values())
      .filter(article => article.category === category)
      .sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime());
  }

  async getArticlesByLanguage(language: string): Promise<Article[]> {
    return Array.from(this.articles.values())
      .filter(article => article.language === language)
      .sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime());
  }

  async searchArticles(query: string): Promise<Article[]> {
    const searchTerm = query.toLowerCase();
    return Array.from(this.articles.values())
      .filter(article => 
        article.title.toLowerCase().includes(searchTerm) ||
        article.description?.toLowerCase().includes(searchTerm) ||
        article.content?.toLowerCase().includes(searchTerm)
      )
      .sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime());
  }

  async createArticle(insertArticle: InsertArticle): Promise<Article> {
    const id = this.currentArticleId++;
    const article: Article = {
      ...insertArticle,
      id,
      fetchedAt: new Date(),
    };
    this.articles.set(id, article);
    return article;
  }

  async createMultipleArticles(insertArticles: InsertArticle[]): Promise<Article[]> {
    const articles: Article[] = [];
    for (const insertArticle of insertArticles) {
      const article = await this.createArticle(insertArticle);
      articles.push(article);
    }
    return articles;
  }

  async deleteOldArticles(hoursOld: number): Promise<void> {
    const cutoffTime = new Date();
    cutoffTime.setHours(cutoffTime.getHours() - hoursOld);
    
    for (const [id, article] of this.articles.entries()) {
      if (article.fetchedAt < cutoffTime) {
        this.articles.delete(id);
      }
    }
  }

  async getAllNewsSources(): Promise<NewsSource[]> {
    return Array.from(this.newsSources.values()).sort(
      (a, b) => a.addedAt.getTime() - b.addedAt.getTime()
    );
  }

  async getActiveNewsSources(): Promise<NewsSource[]> {
    return Array.from(this.newsSources.values())
      .filter(source => source.isActive)
      .sort((a, b) => a.addedAt.getTime() - b.addedAt.getTime());
  }

  async createNewsSource(insertSource: InsertNewsSource): Promise<NewsSource> {
    const id = this.currentSourceId++;
    const source: NewsSource = {
      ...insertSource,
      id,
      addedAt: new Date(),
    };
    this.newsSources.set(id, source);
    return source;
  }

  async deleteNewsSource(id: number): Promise<boolean> {
    return this.newsSources.delete(id);
  }

  async toggleNewsSource(id: number, isActive: boolean): Promise<boolean> {
    const source = this.newsSources.get(id);
    if (source) {
      source.isActive = isActive;
      this.newsSources.set(id, source);
      return true;
    }
    return false;
  }
}

export const storage = new MemStorage();
