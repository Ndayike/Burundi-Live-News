import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { NewsFetcher } from "./services/news-fetcher";
import { insertArticleSchema, insertNewsSourceSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const newsApiKey = process.env.NEWS_API_KEY;
  const newsFetcher = new NewsFetcher(newsApiKey || "");

  // Fetch fresh news every 5 minutes
  setInterval(async () => {
    try {
      console.log("Fetching fresh news articles...");
      const articles = await newsFetcher.fetchBurundiNews();
      if (articles.length > 0) {
        await storage.createMultipleArticles(articles);
        // Clean up old articles (older than 24 hours)
        await storage.deleteOldArticles(24);
        console.log(`Fetched ${articles.length} new articles`);
      }
    } catch (error) {
      console.error("Error in scheduled news fetch:", error);
    }
  }, 5 * 60 * 1000); // 5 minutes

  // Initial news fetch
  setTimeout(async () => {
    try {
      const articles = await newsFetcher.fetchBurundiNews();
      if (articles.length > 0) {
        await storage.createMultipleArticles(articles);
        console.log(`Initial fetch: ${articles.length} articles`);
      }
    } catch (error) {
      console.error("Error in initial news fetch:", error);
    }
  }, 1000);

  // Get all articles
  app.get("/api/articles", async (req, res) => {
    try {
      const { category, language, search } = req.query;
      
      let articles;
      if (search) {
        articles = await storage.searchArticles(search as string);
      } else if (category && category !== "all") {
        articles = await storage.getArticlesByCategory(category as string);
      } else if (language && language !== "all") {
        articles = await storage.getArticlesByLanguage(language as string);
      } else {
        articles = await storage.getAllArticles();
      }
      
      res.json(articles);
    } catch (error) {
      console.error("Error fetching articles:", error);
      res.status(500).json({ message: "Failed to fetch articles" });
    }
  });

  // Get breaking news (latest 5 articles)
  app.get("/api/articles/breaking", async (req, res) => {
    try {
      const articles = await storage.getAllArticles();
      const breakingNews = articles.slice(0, 5);
      res.json(breakingNews);
    } catch (error) {
      console.error("Error fetching breaking news:", error);
      res.status(500).json({ message: "Failed to fetch breaking news" });
    }
  });

  // Manually trigger news refresh
  app.post("/api/articles/refresh", async (req, res) => {
    try {
      const articles = await newsFetcher.fetchBurundiNews();
      if (articles.length > 0) {
        const savedArticles = await storage.createMultipleArticles(articles);
        res.json({ 
          message: `Fetched ${savedArticles.length} new articles`,
          articles: savedArticles 
        });
      } else {
        res.json({ message: "No new articles found" });
      }
    } catch (error) {
      console.error("Error refreshing articles:", error);
      res.status(500).json({ message: "Failed to refresh articles" });
    }
  });

  // Manually fetch from Veridade blog
  app.post("/api/articles/veridade", async (req, res) => {
    try {
      const articles = await newsFetcher.fetchFromVeridadeBlog();
      if (articles.length > 0) {
        const savedArticles = await storage.createMultipleArticles(articles);
        res.json({ 
          message: `Fetched ${savedArticles.length} articles from Veridade blog`,
          articles: savedArticles 
        });
      } else {
        res.json({ message: "No articles found from Veridade blog" });
      }
    } catch (error) {
      console.error("Error fetching from Veridade blog:", error);
      res.status(500).json({ message: "Failed to fetch from Veridade blog" });
    }
  });

  // News sources management
  app.get("/api/sources", async (req, res) => {
    try {
      const sources = await storage.getAllNewsSources();
      res.json(sources);
    } catch (error) {
      console.error("Error fetching sources:", error);
      res.status(500).json({ message: "Failed to fetch sources" });
    }
  });

  app.post("/api/sources", async (req, res) => {
    try {
      const sourceData = insertNewsSourceSchema.parse(req.body);
      const source = await storage.createNewsSource(sourceData);
      res.json(source);
    } catch (error) {
      console.error("Error creating source:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid source data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create source" });
      }
    }
  });

  app.delete("/api/sources/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteNewsSource(id);
      if (success) {
        res.json({ message: "Source deleted successfully" });
      } else {
        res.status(404).json({ message: "Source not found" });
      }
    } catch (error) {
      console.error("Error deleting source:", error);
      res.status(500).json({ message: "Failed to delete source" });
    }
  });

  app.patch("/api/sources/:id/toggle", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { isActive } = req.body;
      const success = await storage.toggleNewsSource(id, isActive);
      if (success) {
        res.json({ message: "Source updated successfully" });
      } else {
        res.status(404).json({ message: "Source not found" });
      }
    } catch (error) {
      console.error("Error toggling source:", error);
      res.status(500).json({ message: "Failed to update source" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
