import { type InsertArticle } from "@shared/schema";

export interface NewsAPIResponse {
  status: string;
  totalResults: number;
  articles: Array<{
    source: { id: string; name: string };
    author: string;
    title: string;
    description: string;
    url: string;
    urlToImage: string;
    publishedAt: string;
    content: string;
  }>;
}

export interface GNewsResponse {
  totalArticles: number;
  articles: Array<{
    title: string;
    description: string;
    content: string;
    url: string;
    image: string;
    publishedAt: string;
    source: { name: string; url: string };
  }>;
}

export class NewsFetcher {
  private apiKey: string;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  async fetchFromVeridadeBlog(): Promise<InsertArticle[]> {
    try {
      // Fetch RSS feed from Veridade blog
      const rssUrl = "https://veridade.blogspot.com/feeds/posts/default?alt=rss";
      const response = await fetch(rssUrl);
      
      if (!response.ok) {
        throw new Error(`Veridade blog RSS error: ${response.status}`);
      }

      const rssText = await response.text();
      
      // Parse RSS XML to extract articles
      const articles = this.parseRSSFeed(rssText);
      return articles;
    } catch (error) {
      console.error("Error fetching from Veridade blog:", error);
      // Return fallback articles with realistic Burundi content
      return this.generateVeridadeFallbackArticles();
    }
  }

  private parseRSSFeed(rssText: string): InsertArticle[] {
    // Simple RSS parsing - in production, you'd use a proper XML parser
    const articles: InsertArticle[] = [];
    
    try {
      // Extract items from RSS
      const itemMatches = rssText.match(/<item[^>]*>[\s\S]*?<\/item>/gi);
      
      if (itemMatches) {
        itemMatches.forEach((item, index) => {
          if (index < 10) { // Limit to 10 articles
            const title = this.extractXMLContent(item, 'title');
            const description = this.extractXMLContent(item, 'description');
            const link = this.extractXMLContent(item, 'link');
            const pubDate = this.extractXMLContent(item, 'pubDate');
            
            if (title && link) {
              articles.push({
                title: this.cleanHTML(title),
                description: this.cleanHTML(description) || "Read the full article for more details...",
                content: this.cleanHTML(description) || "",
                url: link,
                imageUrl: this.extractImageFromContent(description) || "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=800&h=400&fit=crop",
                source: "Veridade Blog",
                category: this.categorizeArticle(title, description || ""),
                language: this.detectLanguage(title, description || ""),
                publishedAt: pubDate ? new Date(pubDate) : new Date(),
              });
            }
          }
        });
      }
    } catch (error) {
      console.error("Error parsing RSS feed:", error);
    }
    
    return articles;
  }

  private extractXMLContent(xml: string, tag: string): string {
    const regex = new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\/${tag}>`, 'i');
    const match = xml.match(regex);
    return match ? match[1].trim() : '';
  }

  private cleanHTML(html: string): string {
    if (!html) return '';
    return html
      .replace(/<[^>]*>/g, '') // Remove HTML tags
      .replace(/&quot;/g, '"')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&#39;/g, "'")
      .replace(/&nbsp;/g, ' ')
      .trim();
  }

  private extractImageFromContent(content: string): string | null {
    if (!content) return null;
    
    const imgMatch = content.match(/src\s*=\s*["']([^"']+)["']/i);
    return imgMatch ? imgMatch[1] : null;
  }

  private generateVeridadeFallbackArticles(): InsertArticle[] {
    // Specific Veridade blog articles to display for 90 days
    const specificArticles = [
      {
        title: "Le Général Major Évariste Ndayishimiye - Leadership et Vision",
        description: "Analyse approfondie du leadership du Président Évariste Ndayishimiye et de sa vision pour l'avenir du Burundi.",
        content: "Une analyse détaillée des réalisations et de la vision du Président Évariste Ndayishimiye...",
        url: "https://veridade.blogspot.com/2025/07/le-general-major-evariste-ndayishimiye.html",
        imageUrl: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800&h=400&fit=crop",
        source: "Veridade Blog",
        category: "Politics",
        language: "French",
        publishedAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
      },
      {
        title: "Que Cherchent Vraiment Museveni et Paul Kagame?",
        description: "Analyse géopolitique des motivations et stratégies des leaders régionaux en Afrique de l'Est.",
        content: "Une exploration des dynamiques politiques complexes dans la région des Grands Lacs...",
        url: "https://veridade.blogspot.com/2025/07/que-cherchent-vraiment-museveni-et-paul.html",
        imageUrl: "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=800&h=400&fit=crop",
        source: "Veridade Blog",
        category: "Politics",
        language: "French",
        publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      },
      {
        title: "S.E. Évariste Ndayishimiye et S.E. Ibrahim Traoré - Coopération Régionale",
        description: "Renforcement des relations diplomatiques et de la coopération entre le Burundi et le Burkina Faso.",
        content: "Les relations bilatérales entre les deux nations africaines se renforcent...",
        url: "https://veridade.blogspot.com/2025/07/se-evariste-ndayishimiye-et-se-ibrahim.html",
        imageUrl: "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=800&h=400&fit=crop",
        source: "Veridade Blog",
        category: "Politics",
        language: "French",
        publishedAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
      },
      {
        title: "La Première Dame Angeline Ndayishimiye - Actions Humanitaires",
        description: "Les initiatives sociales et humanitaires de la Première Dame du Burundi pour l'amélioration des conditions de vie.",
        content: "Madame Angeline Ndayishimiye continue ses actions en faveur des plus démunis...",
        url: "https://veridade.blogspot.com/2025/07/la-premiere-dame-angeline-ndayishimiye.html",
        imageUrl: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800&h=400&fit=crop",
        source: "Veridade Blog",
        category: "Society",
        language: "French",
        publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
      },
      {
        title: "Un Spectacle de Plus - Le Président Trump et la Géopolitique",
        description: "Analyse de l'impact des politiques américaines sur la géopolitique mondiale et africaine.",
        content: "Les implications des décisions politiques américaines sur le continent africain...",
        url: "https://veridade.blogspot.com/2025/07/un-spectacle-de-plus-le-president-trump.html",
        imageUrl: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&h=400&fit=crop",
        source: "Veridade Blog",
        category: "International",
        language: "French",
        publishedAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
      },
      {
        title: "Museveni 81 ans - Candidat pour la Septième Fois",
        description: "Analyse de la longévité politique du Président ougandais et ses implications régionales.",
        content: "Le Président Museveni se présente une fois de plus pour un nouveau mandat...",
        url: "https://veridade.blogspot.com/2025/06/museveni-81-ans-candidat-pour-la.html",
        imageUrl: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800&h=400&fit=crop",
        source: "Veridade Blog",
        category: "Politics",
        language: "French",
        publishedAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
      },
      {
        title: "Comprendre la Nature du Conflit entre le Rwanda et la RDC",
        description: "Analyse approfondie des tensions historiques et contemporaines dans la région des Grands Lacs.",
        content: "Les racines profondes du conflit entre le Rwanda et la République Démocratique du Congo...",
        url: "https://veridade.blogspot.com/2025/06/comprendre-la-nature-du-conflit-entre.html",
        imageUrl: "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=800&h=400&fit=crop",
        source: "Veridade Blog",
        category: "International",
        language: "French",
        publishedAt: new Date(Date.now() - 7 * 60 * 60 * 1000),
      },
      {
        title: "Cinq Ans de Gouvernance du Président Évariste Ndayishimiye",
        description: "Bilan des réalisations et défis de la première moitié du mandat présidentiel.",
        content: "Un regard rétrospectif sur les cinq années de leadership du Président Ndayishimiye...",
        url: "https://veridade.blogspot.com/2025/06/cinq-ans-de-gouvernance-du-president.html",
        imageUrl: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800&h=400&fit=crop",
        source: "Veridade Blog",
        category: "Politics",
        language: "French",
        publishedAt: new Date(Date.now() - 8 * 60 * 60 * 1000),
      },
      {
        title: "Thérèse Kayikwamba Wagner - Une Voix pour la Justice",
        description: "Portrait d'une figure importante dans la défense des droits humains et de la justice sociale.",
        content: "L'engagement de Thérèse Kayikwamba Wagner pour la justice et les droits humains...",
        url: "https://veridade.blogspot.com/2025/06/therese-kayikwamba-wagner-une-voix.html",
        imageUrl: "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=800&h=400&fit=crop",
        source: "Veridade Blog",
        category: "Society",
        language: "French",
        publishedAt: new Date(Date.now() - 9 * 60 * 60 * 1000),
      },
      {
        title: "La Prostitution en Israël en 2025 - Enjeux Sociétaux",
        description: "Analyse des problématiques sociales contemporaines et des défis humanitaires.",
        content: "Une exploration des enjeux sociaux complexes dans le contexte moyen-oriental...",
        url: "https://veridade.blogspot.com/2025/06/la-prostitution-en-israel-en-2025.html",
        imageUrl: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800&h=400&fit=crop",
        source: "Veridade Blog",
        category: "Society",
        language: "French",
        publishedAt: new Date(Date.now() - 10 * 60 * 60 * 1000),
      }
    ];

    return specificArticles;
  }

  async fetchFromNewsAPI(query: string = "Burundi"): Promise<InsertArticle[]> {
    try {
      const url = `https://newsapi.org/v2/everything?q=${encodeURIComponent(query)}&apiKey=${this.apiKey}&language=en,fr&sortBy=publishedAt&pageSize=50`;
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`NewsAPI error: ${response.status}`);
      }

      const data: NewsAPIResponse = await response.json();
      
      return data.articles.map(article => ({
        title: article.title,
        description: article.description,
        content: article.content,
        url: article.url,
        imageUrl: article.urlToImage,
        source: article.source.name,
        category: this.categorizeArticle(article.title, article.description),
        language: this.detectLanguage(article.title, article.description),
        publishedAt: new Date(article.publishedAt),
      }));
    } catch (error) {
      console.error("Error fetching from NewsAPI:", error);
      return [];
    }
  }

  async fetchFromGNews(query: string = "Burundi"): Promise<InsertArticle[]> {
    try {
      const gNewsApiKey = process.env.GNEWS_API_KEY;
      if (!gNewsApiKey) {
        console.error("GNEWS_API_KEY not found");
        return [];
      }

      const url = `https://gnews.io/api/v4/search?q=${encodeURIComponent(query)}&token=${gNewsApiKey}&lang=en,fr&max=50`;
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`GNews error: ${response.status}`);
      }

      const data: GNewsResponse = await response.json();
      
      return data.articles.map(article => ({
        title: article.title,
        description: article.description,
        content: article.content,
        url: article.url,
        imageUrl: article.image,
        source: article.source.name,
        category: this.categorizeArticle(article.title, article.description),
        language: this.detectLanguage(article.title, article.description),
        publishedAt: new Date(article.publishedAt),
      }));
    } catch (error) {
      console.error("Error fetching from GNews:", error);
      return [];
    }
  }

  async fetchBurundiNews(): Promise<InsertArticle[]> {
    const allArticles: InsertArticle[] = [];

    // Always include specific Veridade blog articles (priority for 90 days)
    const veridadeSpecificArticles = this.generateVeridadeFallbackArticles();
    allArticles.push(...veridadeSpecificArticles);
    console.log(`Added ${veridadeSpecificArticles.length} specific Veridade articles`);

    try {
      // Try to fetch additional articles from Veridade blog RSS
      const veridadeRSSArticles = await this.fetchFromVeridadeBlog();
      allArticles.push(...veridadeRSSArticles);
      console.log(`Fetched ${veridadeRSSArticles.length} additional articles from Veridade blog`);
    } catch (error) {
      console.error("Error fetching additional Veridade blog articles:", error);
    }

    // Try to fetch from other APIs for supplementary content
    const queries = ["Burundi", "Bujumbura"];
    for (const query of queries) {
      try {
        const newsAPIArticles = await this.fetchFromNewsAPI(query);
        allArticles.push(...newsAPIArticles);
      } catch (error) {
        console.error(`Error fetching articles for query "${query}":`, error);
      }
    }

    // Remove duplicates based on URL
    const uniqueArticles = allArticles.filter((article, index, self) =>
      index === self.findIndex(a => a.url === article.url)
    );

    // Limit to prevent overwhelming storage (keep specific articles + some additional)
    return uniqueArticles.slice(0, 20);
  }

  private generateSampleBurundiNews(): InsertArticle[] {
    const sampleArticles = [
      {
        title: "Burundi Launches Major Infrastructure Development Project",
        description: "The government announces a comprehensive infrastructure plan to modernize transportation and communication networks across the country.",
        content: "President Ndayishimiye unveiled an ambitious infrastructure development project aimed at connecting rural and urban areas through improved roads, bridges, and digital networks...",
        url: "https://burundi-gov.bi/infrastructure-2024",
        imageUrl: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&h=400&fit=crop",
        source: "Government of Burundi",
        category: "Politics",
        language: "English",
        publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      },
      {
        title: "Agriculture Moderne: Le Café Burundais Conquiert les Marchés Internationaux",
        description: "Les producteurs de café burundais signent des contrats d'exportation importants avec des acheteurs européens et américains.",
        content: "Le secteur agricole burundais connaît une transformation remarquable avec l'introduction de nouvelles techniques de culture et de traitement du café...",
        url: "https://agriculture.bi/cafe-export-2024",
        imageUrl: "https://images.unsplash.com/photo-1497515114629-f71d768fd07c?w=800&h=400&fit=crop",
        source: "Agriculture Burundi",
        category: "Agriculture",
        language: "French",
        publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
      },
      {
        title: "Burundi National Football Team Advances in AFCON Qualifiers",
        description: "The Swallows secure a crucial victory in their latest qualifier match, boosting hopes for continental tournament participation.",
        content: "In a thrilling match at the Prince Louis Rwagasore Stadium, Burundi's national team demonstrated exceptional skill and determination...",
        url: "https://sports.bi/afcon-qualifiers-victory",
        imageUrl: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=800&h=400&fit=crop",
        source: "Burundi Sports Federation",
        category: "Sports",
        language: "English",
        publishedAt: new Date(Date.now() - 6 * 60 * 60 * 1000), // 6 hours ago
      },
      {
        title: "Système de Santé: Nouveaux Centres Médicaux dans les Provinces",
        description: "Le ministère de la santé inaugure plusieurs centres de santé modernes pour améliorer l'accès aux soins dans les zones rurales.",
        content: "Dans le cadre de la politique nationale de santé pour tous, le gouvernement burundais a officiellement ouvert cinq nouveaux centres médicaux...",
        url: "https://sante.bi/nouveaux-centres-medicaux",
        imageUrl: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800&h=400&fit=crop",
        source: "Ministère de la Santé",
        category: "Health",
        language: "French",
        publishedAt: new Date(Date.now() - 8 * 60 * 60 * 1000), // 8 hours ago
      },
      {
        title: "Economic Growth Shows Promise as Tourism Sector Rebounds",
        description: "Recent economic indicators suggest steady growth as international tourists return to discover Burundi's natural beauty and cultural heritage.",
        content: "The National Institute of Statistics reports encouraging economic data, with the tourism sector leading recovery efforts...",
        url: "https://economics.bi/tourism-growth-2024",
        imageUrl: "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=800&h=400&fit=crop",
        source: "Economic Review Burundi",
        category: "Economy",
        language: "English",
        publishedAt: new Date(Date.now() - 10 * 60 * 60 * 1000), // 10 hours ago
      },
      {
        title: "Éducation: Digitalisation des Écoles dans la Capitale Gitega",
        description: "Un programme pilote d'équipement numérique est lancé dans les établissements scolaires de la capitale politique.",
        content: "La ville de Gitega devient le premier site d'expérimentation pour le projet national de digitalisation de l'éducation...",
        url: "https://education.bi/digitalisation-gitega",
        imageUrl: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=800&h=400&fit=crop",
        source: "Ministère de l'Éducation",
        category: "Education",
        language: "French",
        publishedAt: new Date(Date.now() - 12 * 60 * 60 * 1000), // 12 hours ago
      },
      {
        title: "Cultural Heritage Festival Celebrates Burundian Traditions",
        description: "The annual heritage festival in Bujumbura showcases traditional music, dance, and crafts, attracting visitors from across East Africa.",
        content: "Bujumbura's cultural center came alive with vibrant performances and exhibitions celebrating Burundi's rich cultural heritage...",
        url: "https://culture.bi/heritage-festival-2024",
        imageUrl: "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=800&h=400&fit=crop",
        source: "Cultural Ministry",
        category: "Culture",
        language: "English",
        publishedAt: new Date(Date.now() - 14 * 60 * 60 * 1000), // 14 hours ago
      },
      {
        title: "Assemblée Nationale: Débats sur la Politique Environnementale",
        description: "Les députés examinent un nouveau projet de loi pour la protection de l'environnement et la gestion durable des ressources naturelles.",
        content: "Au cours d'une session parlementaire marathon, les représentants du peuple ont débattu des enjeux environnementaux majeurs...",
        url: "https://parlement.bi/loi-environnement-2024",
        imageUrl: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800&h=400&fit=crop",
        source: "Assemblée Nationale du Burundi",
        category: "Politics",
        language: "French",
        publishedAt: new Date(Date.now() - 16 * 60 * 60 * 1000), // 16 hours ago
      },
      {
        title: "Youth Entrepreneurship Program Launches Across Provinces",
        description: "A new government initiative provides training and funding opportunities for young entrepreneurs in technology and agriculture sectors.",
        content: "The Ministry of Youth and Vocational Training announced a comprehensive program designed to foster entrepreneurship among Burundian youth...",
        url: "https://youth.bi/entrepreneurship-program-2024",
        imageUrl: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800&h=400&fit=crop",
        source: "Ministry of Youth",
        category: "Economy",
        language: "English",
        publishedAt: new Date(Date.now() - 18 * 60 * 60 * 1000), // 18 hours ago
      },
      {
        title: "Technologie: Expansion du Réseau Internet Rural",
        description: "Un projet d'infrastructure numérique vise à connecter les communautés rurales isolées à l'internet haut débit.",
        content: "L'Agence de Régulation des Télécommunications annonce un investissement majeur dans l'extension de la couverture internet...",
        url: "https://telecom.bi/internet-rural-2024",
        imageUrl: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&h=400&fit=crop",
        source: "Télécoms Burundi",
        category: "Technology",
        language: "French",
        publishedAt: new Date(Date.now() - 20 * 60 * 60 * 1000), // 20 hours ago
      }
    ];

    return sampleArticles;
  }

  private categorizeArticle(title: string, description: string): string {
    const text = (title + " " + (description || "")).toLowerCase();
    
    if (text.includes("politic") || text.includes("government") || text.includes("parliament") || text.includes("election")) {
      return "Politics";
    } else if (text.includes("econom") || text.includes("business") || text.includes("trade") || text.includes("market")) {
      return "Economy";
    } else if (text.includes("sport") || text.includes("football") || text.includes("soccer") || text.includes("basketball")) {
      return "Sports";
    } else if (text.includes("health") || text.includes("medical") || text.includes("hospital") || text.includes("doctor")) {
      return "Health";
    } else if (text.includes("education") || text.includes("school") || text.includes("university") || text.includes("student")) {
      return "Education";
    } else if (text.includes("culture") || text.includes("art") || text.includes("music") || text.includes("tradition")) {
      return "Culture";
    } else if (text.includes("agriculture") || text.includes("farm") || text.includes("coffee") || text.includes("crop")) {
      return "Agriculture";
    } else {
      return "General";
    }
  }

  private detectLanguage(title: string, description: string): string {
    const text = (title + " " + (description || "")).toLowerCase();
    
    // French indicators
    if (text.includes(" le ") || text.includes(" la ") || text.includes(" les ") || text.includes(" du ") || text.includes(" de ") || text.includes(" et ")) {
      return "French";
    }
    
    // Kirundi indicators (basic detection)
    if (text.includes("uburundi") || text.includes("bujumbura") || text.includes("gitega")) {
      return "Kirundi";
    }
    
    // Default to English
    return "English";
  }
}
